<?php

return [
    'jazzcash' => [
        'MERCHANT_ID' 	 => '',
        'PASSWORD' 		 => '',
		'INTEGERITY_SALT'=> '',
		'CURRENCY_CODE'  => 'PKR',
		'VERSION'		 => '1.1',
		'LANGUAGE'  	 => 'EN',
		
		
		'RETURN_URL'  => 'http://127.0.0.1:8000/paymentStatus',
		'TRANSACTION_POST_URL'  => 'https://sandbox.jazzcash.com.pk/CustomerPortal/transactionmanagement/merchantform/'
		
    ]
];
