<?php

namespace Tapatalk\XF\Mail;

class Mail extends XFCP_Mail
{


}