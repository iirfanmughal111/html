<?php

namespace Tapatalk\XF\Mail;

class Mailer extends XFCP_Mailer
{


}