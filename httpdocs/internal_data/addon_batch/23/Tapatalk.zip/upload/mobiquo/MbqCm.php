<?php

defined('MBQ_IN_IT') or exit;

/**
 * common method class
 */
Class MbqCm extends MbqBaseCm {
    
    public function __construct() {
        parent::__construct();
    }
 }

