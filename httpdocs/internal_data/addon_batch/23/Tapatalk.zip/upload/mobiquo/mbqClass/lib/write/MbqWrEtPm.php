<?php

defined('MBQ_IN_IT') or exit;

MbqMain::$oClk->includeClass('MbqBaseWrEtPm');

/**
 * private message write class
 */
Class MbqWrEtPm extends MbqBaseWrEtPm {
    
    public function __construct() {
    }
  
}
