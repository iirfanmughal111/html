<?php

defined('MBQ_IN_IT') or exit;

MbqMain::$oClk->includeClass('MbqBaseWrEtPoll');

/**
 * poll write class
 */
Class MbqWrEtPoll extends MbqBaseWrEtPoll {

    public function __construct() {
    }

    /**
     * vote
     */
    public function vote($oMbqEtPoll) {
       
    }

    /**
     * edit_poll
     */
    public function editPoll($oMbqEtPoll) {
      
    }
}