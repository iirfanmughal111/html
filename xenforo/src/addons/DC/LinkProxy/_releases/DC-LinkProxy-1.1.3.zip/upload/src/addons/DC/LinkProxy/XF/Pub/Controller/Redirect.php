<?php

namespace DC\LinkProxy\XF\Pub\Controller;

use XF\Mvc\ParameterBag;
use XF\Mvc\Reply\AbstractReply;

class Redirect extends \XF\Pub\Controller\AbstractController
{
    public function actionIndex() {
        $encodedUrl = isset($_GET['to']) ? $_GET['to'] : '';
        
        if (!$encodedUrl) return $this->error(\XF::phrase('DC_LinkProxy_url_not_valid'));

        $urlDecoded = base64_decode($encodedUrl);

        if (filter_var($urlDecoded, FILTER_VALIDATE_URL) === FALSE) 
        {
            return $this->error(\XF::phrase('DC_LinkProxy_url_not_valid'));
        }   
        
        $user_link_setting = $this->finder('DC\LinkProxy:LinkProxyList')->where('user_group_id',  \XF::visitor()->user_group_id)->fetchOne();
        
        $redirect_time = $user_link_setting ? $user_link_setting->redirect_time : $this->app()->options()->DC_LinkProxy_AutoRedirection__time;
        $html = $user_link_setting ? $user_link_setting->link_redirect_html : '';
        
        $viewParams = [
            'url' => $urlDecoded,
            'redirect_time'=>$redirect_time,
            'html'=>$html,

        ];
        return $this->view('DC\LinkProxy:Redirecting', 'DC_LinkProxy_Redirecting', $viewParams);
    }
}