<?php

// ################## THIS IS A GENERATED FILE ##################
// DO NOT EDIT DIRECTLY. EDIT THE CLASS EXTENSIONS IN THE CONTROL PANEL.

namespace FS\Escrow\XF\Admin\Controller
{
	class XFCP_User extends \XF\Admin\Controller\User {}
}

namespace FS\Escrow\XF\Entity
{
	class XFCP_Thread extends \XF\Entity\Thread {}
	class XFCP_User extends \XF\Entity\User {}
}

namespace FS\Escrow\XF\Pub\Controller
{
	class XFCP_Forum extends \XF\Pub\Controller\Forum {}
	class XFCP_Member extends \XF\Pub\Controller\Member {}
	class XFCP_Post extends \XF\Pub\Controller\Post {}
	class XFCP_Thread extends \XF\Pub\Controller\Thread {}
}

namespace FS\Escrow\XF\Service\Thread
{
	class XFCP_Creator extends \XF\Service\Thread\Creator {}
}