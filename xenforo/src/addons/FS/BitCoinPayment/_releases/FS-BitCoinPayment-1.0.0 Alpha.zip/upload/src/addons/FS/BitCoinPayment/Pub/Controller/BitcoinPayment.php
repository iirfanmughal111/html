<?php

namespace FS\BitCoinPayment\Pub\Controller;
use XF\Mvc\ParameterBag;
use XF\Pub\Controller\AbstractController;
use XF\Mvc\RouteMatch;



class BitcoinPayment extends AbstractController
{

    
    public function actionIndex(ParameterBag $params)
    {
        if (\Xf::visitor()->user_id!=0){
          return $this->view('FS\BitCoinPayment', 'fs_BitCoinPayment_deposit');
        }
        return $this->redirect($this->buildLink('login'));
 
    }


   





    
}