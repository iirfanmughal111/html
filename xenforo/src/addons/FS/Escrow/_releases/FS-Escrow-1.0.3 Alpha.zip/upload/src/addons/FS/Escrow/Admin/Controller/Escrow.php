<?php

namespace FS\Escrow\Admin\Controller;

use XF\Mvc\ParameterBag;
use XF\Admin\Controller\AbstractController;
use XF\Mvc\RouteMatch;

class Escrow extends AbstractController
{
    public function actionIndex(ParameterBag $params)
    {

        if ($this->filter('search', 'uint')) {
            $finder = $this->getSearchFinder();
            // if (count($finder->getConditions()) == 0) {
            //     return $this->error(\XF::phrase('please_complete_required_field'));
            // }
        } else {
            $finder = $this->finder('FS\Escrow:Escrow');
        }

        $page = $this->filterPage($params->page);
        $perPage = 25;
        $finder->limitByPage($page, $perPage);

        $viewpParams = [
            'page' => $page,
            'total' => $finder->total(),
            'perPage' => $perPage,
            'escrows' => $finder->fetch(),
            'conditions' => $this->filterSearchConditions(),
        ];

        return $this->view('FS\Escrow:Escrow', 'fs_escrow_admin_list', $viewpParams);
    }

    protected function getSearchFinder()
    {
        $conditions = $this->filterSearchConditions();
        $finder = $this->finder('FS\Escrow:Escrow');

        if ($conditions['fs_escrow_start_username'] != '') {

            $User = $this->finder('XF:User')->where('username', $conditions['fs_escrow_start_username'])->fetchOne();
            if ($User) {
                $finder->where('user_id', $User['user_id']);
            }
        }
        if ($conditions['fs_escrow_mentioned_username'] != '') {

            $User = $this->finder('XF:User')->where('username', $conditions['fs_escrow_mentioned_username'])->fetchOne();
            if ($User) {
                $finder->where('to_user', $User['user_id']);
            }
        }

        if ($conditions['fs_escrow_status'] != 'all') {
            if (intval($conditions['fs_escrow_status']) >= 0 && intval($conditions['fs_escrow_status']) <= 4) {
                $finder->where('escrow_status', intval($conditions['fs_escrow_status']));
            }
        }


        return $finder;
    }



    public function filterPage($page = 0, $inputName = 'page')
    {
        return max(1, intval($page) ?: $this->filter($inputName, 'uint'));
    }

    public function actionRefineSearch(ParameterBag $params)
    {

        $viewParams = [
            'conditions' => $this->filterSearchConditions(),
        ];
        return $this->view('FS\Escrow:Escrow', 'fs_escrow_search_filter', $viewParams);
    }

    protected function filterSearchConditions()
    {
        return $this->filter([
            'fs_escrow_username' => 'str',
            'fs_escrow_status' => 'str',
            'fs_escrow_start_username' => 'str',
            'fs_escrow_mentioned_username' => 'str',

        ]);
    }
    
    protected function requestTransferFunds($escrow,$amount,$type){
        $app = \XF::app();
        
        if ($escrow->Thread->User->crypto_address && $escrow->Thread->User->crypto_address !=null){
            $source = $escrow->Thread->User->crypto_address;
        }else{
            $source =  $this->getAddress($escrow->Thread->User);
        }
        if ($type=='to_user'){
            if ($escrow->User->crypto_address && $escrow->User->crypto_address !=null){
                $destination =  $escrow->User->crypto_address;
            }else{
                $destination =  $this->getAddress($escrow->User);
            }
        }
        else if($type=='admin'){
            $percentageUser = $this->em()->findOne('XF:User', ['user_id' => intval($this->app()->options()->fs_escrow_admin_Id)]);
            if ($percentageUser->crypto_address && $percentageUser->crypto_address !=null){
                $destination= $percentageUser->crypto_address;
            }else{
                $destination =  $this->getAddress($percentageUser);
            }
        }
 
        
        $ch = curl_init();
        $data = json_encode(array(
            "RequestId"=>$escrow->User->user_id.'_'.$escrow->User->username,
            "SourceAddress"=> $source,
            'DestinationAddress'=>$destination, 
            "Currency"=> $app->options()->fs_escrow_currency,
            "Amount"=> $amount,
            "IsSenderCommission"=>true,
            "Comment"=> 'Funds transfer',
            "publickey"=> $app->options()->fs_escrow_api,
        ));
        curl_setopt($ch, CURLOPT_URL,$app->options()->fs_escrow_bit_base_url."/transaction/withdraw");
        curl_setopt($ch, CURLOPT_POST, 1);
    
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
        ]);
        curl_setopt($ch, CURLOPT_POSTFIELDS,$data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $server_output = curl_exec($ch);
        curl_close($ch);
        $response = json_decode($server_output,true);
        return $response;

    } 
    
    
}