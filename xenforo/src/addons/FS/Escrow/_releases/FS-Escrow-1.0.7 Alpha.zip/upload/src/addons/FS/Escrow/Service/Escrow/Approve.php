<?php


namespace FS\Escrow\Service\Escrow;


use XF\Service\AbstractService;
use FS\Escrow\Entity\WithdrawRequest;

class Approve extends AbstractService
{
   
    protected $request;

    protected $notifyRunTime = 3;

    public function __construct(\XF\App $app, WithdrawRequest $request)
    {
        parent::__construct($app);
        $this->request = $request;
    }

    public function getRequest()
    {
        return $this->request;
    }

    public function setNotifyRunTime($time)
    {
        $this->notifyRunTime = $time;
    }

    public function approve()
    {
        if ($this->request->request_state == 'moderated')
        {
            $this->request->request_state = 'visible';
            $this->request->save();

            XF::app()->jobManager()->enqueueUnique('WithDraw', 'FS\Escrow:WithDraw', [], false);
           // $this->app()->jobManager()->runUnique('WithDraw',20);

            // /** @var \Z61\Classifieds\Service\Listing\Notify $notifier */
            // $notifier = $this->service('Z61\Classifieds:Listing\Notify', $this->listing);
            // $notifier->notifyAndEnqueue($this->notifyRunTime);
            return true;
        }
        else
        {
            return false;
        }
    }
}