<?php

namespace FS\Escrow\Notifier\Transaction;

use XF\Notifier\AbstractNotifier;
use FS\Escrow\Entity\Transaction;

class TransactionAlert extends AbstractNotifier
{
       /** @var Escrow $esction */
       private $transaction;

       public function __construct(\XF\App $app, Transaction $transaction)
       {
           parent::__construct($app);
   
           $this->transaction = $transaction;
       }
   
       public function canNotify(\XF\Entity\User $user)
       {
           return true;
       }

       public function escrowDepositConfirmAlert($status)
       {
            $app = \XF::app();
   
           $transaction = $this->transaction;
           $admin = $app->finder('XF:User', ['user_id' => intval($this->app()->options()->fs_escrow_admin_Id)])->fetchOne();
           return $this->basicAlert(
               $transaction->User,
               intval($this->app()->options()->fs_escrow_admin_Id),
               $admin->username,
               'fs_escrow_transaction',
               $transaction->transaction_id,
               'deposit_confirm',
               [
                   'amount'=>$transaction->transaction_amount,
                   'username'=>$transaction->User->username,
                   'status'=>$status
               ]
           );
       }

       public function escrowWithdrawConfirmAlert($status)
       {
            $app = \XF::app();
   
           $transaction = $this->transaction;
        //   var_dump($status);
           $admin = $app->finder('XF:User', ['user_id' => intval($this->app()->options()->fs_escrow_admin_Id)])->fetchOne();
           return $this->basicAlert(
               $transaction->User,
               intval($this->app()->options()->fs_escrow_admin_Id),
               $admin->username,
               'fs_escrow_transaction',
               $transaction->transaction_id,
               'withdraw_confirm',
               [
                   'amount'=>$transaction->transaction_amount,
                   'username'=>$transaction->User->username,
                   'status'=>$status
               ]
           );
       }
    
}