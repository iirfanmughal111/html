<?php

namespace FS\Escrow\Service\Escrow;

use XF\Mvc\FormAction;

class EscrowServ extends \XF\Service\AbstractService
{
    public function escrowTransaction($user_id, $amount, $current_amt, $type, $escrow_id,$status=null)
    {
        $newAmount = $this->encrypt($this->licenseData($amount));
        $curr_amount = $this->encrypt($this->licenseData($current_amt));

        $transaction = $this->em()->create('FS\Escrow:Transaction');
        $transaction->user_id = $user_id;
        $transaction->transaction_amount = $newAmount;
        $transaction->current_amount = $curr_amount;
        $transaction->transaction_type = $type;
        $transaction->escrow_id = $escrow_id;
        $transaction->status = $status ?  $status : 0;

        $transaction->save();

        return $transaction;
    }

    public function getTransactionList()
    {
        $options = \XF::options();
        $ch = curl_init();
        $data = json_encode(array(
            "publickey"=> $options->fs_escrow_api,
        ));
        curl_setopt($ch, CURLOPT_URL,$options->fs_escrow_bit_base_url."/transaction/list");
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
        ]);
        curl_setopt($ch, CURLOPT_POSTFIELDS,$data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $server_output = curl_exec($ch);
        curl_close($ch);
        $response = json_decode($server_output,true);
        return $response;
   }


    public function requestTransferFunds($request){
        
        $app = \XF::app();
        $source =  $request->address_from;
        $destination =  $request->address_to;
        $ch = curl_init();
        $data = json_encode(array(
            "RequestId"=>$request->req_id,
            "SourceAddress"=> $source,
            'DestinationAddress'=>$destination, 
            "Currency"=> $app->options()->fs_escrow_currency,
            "Amount"=> $request->amount,
            "IsSenderCommission"=>true,
            "Comment"=> 'Funds transfer',
            "publickey"=> $app->options()->fs_escrow_api,
        ));
        curl_setopt($ch, CURLOPT_URL,$app->options()->fs_escrow_bit_base_url."/transaction/withdraw");
        curl_setopt($ch, CURLOPT_POST, 1);
    
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
        ]);
        curl_setopt($ch, CURLOPT_POSTFIELDS,$data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $server_output = curl_exec($ch);
        curl_close($ch);
        $response = json_decode($server_output,true);
        if ( $response && $response['Status'] == 'Success') { 
            $request->Transaction->fastUpdate('transaction_type','Funds Transferd');
          

        }else{
            $errorMessage = implode(' ',preg_split('/(?=[A-Z])/', $response['Error']['Code']));
            $request->Transaction->fastUpdate('transaction_type',$errorMessage);
           
        }

        

    } 

    

   public function encrypt(array $data)
	{
            
          

		$data = json_encode($data);

		$packed = unpack('H*', $data);

		return $packed[1];
	}

	
	public function decrypt($hex)
	{
		$text = pack('H*', $hex);

		if (!$text) {
			return false;
		}

		$data = @json_decode($text, true);

		if (!is_array($data)) {
			return false;
		}

		return $data;
	}

    public function licenseData($amount) {
        $app = \XF::app();
        $type = $app->options()->fs_escrow_currency;
        $data = array(
            'amount' => $amount,
            'amount_type' => $type,
        );

        return $data;
    }

    
    
}