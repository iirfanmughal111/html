<?php

namespace FS\Escrow\Pub\Controller;

use XF\Mvc\ParameterBag;
use XF\Pub\Controller\AbstractController;
use XF\Mvc\RouteMatch;
use db;
include __DIR__ . '/../../qrcode/phpqrcode/qrlib.php';

class Escrow extends AbstractController
{

    public function actionIndex(ParameterBag $params)
    {

        $visitor = \XF::visitor();
        $rules[] = [
            'message' => \XF::phrase('fs_escrow_rules'),
            "display_image" => "avatar",
            "display_style" => "primary",

        ];

        if ($this->filter('search', 'uint') || $this->filterSearchConditions()) {
            $finder = $this->getSearchFinder();
        } else {
            $finder = $this->finder('FS\Escrow:Escrow')->where('thread_id', '!=', 0)->whereOr([['to_user', $visitor->user_id], ['user_id' => $visitor->user_id]]);
        }

        $page = $this->filterPage($params->page);
        $perPage = 15;
        $finder->limitByPage($page, $perPage);
        $viewpParams = [
            'rules' => $rules,
            'page' => $page,
            'total' => $finder->total(),
            'perPage' => $perPage,
            'stats' => $this->auctionStatistics(),
            'escrowsCount' => $this->auctionEscrowCount(),
            'escrows' => $finder->order('last_update', 'desc')->fetch(),
            'conditions' => $this->filterSearchConditions(),
            'isSelected' => $this->filter(['type' => 'str']),

        ];


        return $this->view('FS\Escrow', 'fs_escrow_landing', $viewpParams);
    }

    protected function getSearchFinder()
    {
        $visitor = \XF::visitor();
        $conditions = $this->filterSearchConditions();
        $finder = $this->finder('FS\Escrow:Escrow')->where('thread_id', '!=', 0);
        $search = 0;
        if ($conditions['fs_escrow_mentioned_username'] != '') {

            $User = $this->finder('XF:User')->where('username', $conditions['fs_escrow_mentioned_username'])->fetchOne();
            if ($User) {
                $finder->where('user_id', $User['user_id']);
                $finder->where('to_user', $visitor->user_id);
                $search = 1;
            }
        }
        if ($conditions['fs_escrow_status'] != 'all') {
            if (intval($conditions['fs_escrow_status']) > 0 && intval($conditions['fs_escrow_status']) <= 5) {
                $finder->whereOr([['to_user', $visitor->user_id], ['user_id' => $visitor->user_id]]);
                $finder->where('escrow_status', (intval($conditions['fs_escrow_status']) - 1));
                $search = 1;
            }
        }

        if (isset($conditions['type']) && $conditions['type'] != '') {
            if ($conditions['type'] == 'my') {
                $finder->where('user_id', $visitor->user_id);
                $search = 1;
            } else if ($conditions['type'] == 'mentioned') {
                $finder->where('to_user', $visitor->user_id);
                $search = 1;
            }
        }
        if (!$search) {
            $finder->whereOr([['to_user', $visitor->user_id], ['user_id' => $visitor->user_id]]);
        }

        return $finder;
    }

    public function filterPage($page = 0, $inputName = 'page')
    {
        return max(1, intval($page) ?: $this->filter($inputName, 'uint'));
    }

    public function actionRefineSearch(ParameterBag $params)
    {

        $viewParams = [
            'conditions' => $this->filterSearchConditions(),
        ];
        return $this->view('FS\Escrow:Escrow', 'fs_escrow_public_search_filter', $viewParams);
    }

    protected function filterSearchConditions()
    {
        $filters = $this->filter([
            'fs_escrow_status' => 'str',
            'fs_escrow_mentioned_username' => 'str',
            'type' => 'str'

        ]);
        //   if ($filters['type']=='my'){
        //         $filters['isSelected'] = 'my';
        //     }
        //     else if ($filters['type']=='mentioned'){
        //         $filters['isSelected'] = 'mentioned';
        //     }
        return $filters;
    }
    protected function auctionEscrowCount()
    {
        $visitor = \XF::visitor();

        $finder = $this->finder('FS\Escrow:Escrow')->whereOr([['to_user', $visitor->user_id], ['user_id' => $visitor->user_id]])->where('thread_id', '!=', 0);
        $finderMentioned = clone $finder;
        $finderMy = clone $finder;



        return [
            'all' => [
                'title' => \XF::phrase('fs_escrow_all'),
                'type' => 'all',
                'count' => $finder->total(),
            ],

            'my_escrow' => [
                'title' => \XF::phrase('fs_my_escrow'),
                'type' => 'my',
                'count' => $finderMy->where('user_id', $visitor->user_id)->total(),
            ],

            'mentioned_escrow' => [
                'title' => \XF::phrase('fs_mentioned_escrow'),
                'type' => 'mentioned',
                'count' => $finderMentioned->where('to_user', $visitor->user_id)->total(),
            ],



        ];
    }

    protected function auctionStatistics()
    {
        $visitor = \XF::visitor();

        $finder = $this->finder('FS\Escrow:Escrow')->whereOr([['to_user', $visitor->user_id], ['user_id' => $visitor->user_id]])->where('thread_id', '!=', 0);
        $finder0 = clone $finder;
        $finder1 = clone $finder;
        $finder2 = clone $finder;
        $finder3 = clone $finder;
        $finder4 = clone $finder;

        return [

            'status_0' => [
                'title' => \XF::phrase('fs_escrow_status_0'),
                'count' => $finder0->where('escrow_status', 0)->total(),
            ],

            'status_1' => [
                'title' => \XF::phrase('fs_escrow_status_1'),
                'count' => $finder1->where('escrow_status', 1)->total(),
            ],

            'status_2' => [
                'title' => \XF::phrase('fs_escrow_status_2'),
                'count' => $finder2->where('escrow_status', 2)->total(),
            ],

            'status_3' => [
                'title' => \XF::phrase('fs_escrow_status_3'),
                'count' => $finder3->where('escrow_status', 3)->total(),
            ],

            'status_4' => [
                'title' => \XF::phrase('fs_escrow_status_4'),
                'count' => $finder4->where('escrow_status', 4)->total(),
            ],

        ];
    }


    public function actionAdd(ParameterBag $params)
    {

        $options = $this->app()->options();

        $forum = $this->finder('XF:Forum')->where('node_id', intval($options->fs_escrow_applicable_forum))->fetchOne();

        return $this->redirect($this->buildLink('forums/post-thread', $forum));

        $viewpParams = [];
        return $this->view('FS\Escrow', 'fs_escrow_addEdit', $viewpParams);
    }

    public function actionWithdraw(ParameterBag $params)
    {
        $visitor = \XF::visitor();
        if ($visitor->user_id == 0) {
            throw $this->exception(
                $this->error(\XF::phrase("fs_escrow_not_allowed"))
            );
        }
        $source_address = $this->getAddress($visitor);
        $viewpParams = [
            'source_address' => $source_address,
            'pageSelected' => 'escrow/withdraw',
        ];
        return $this->view('FS\Escrow', 'fs_escrow_wihdraw', $viewpParams);
    }
    
    public function actionWithdrawRequest(ParameterBag $params)
    {
        if (!$this->isPost()){
            return $this->redirect($this->buildLink('escrow/withdraw'), 'false');
        }
        
        $visitor = \XF::visitor();
        if ($visitor->user_id == 0) {
            throw $this->exception(
                $this->error(\XF::phrase("fs_escrow_not_allowed"))
            );
        }
        $inputs = $this->filterWithdrawAmountInputs();
        
        if ($this->app()->options()->fs_escrow_otp_option){
            $this->saveWithdrawRequest($inputs);
            return $this->redirect($this->buildLink('members/'.$visitor->username.'.'.$visitor->user_id.'/#escrow-logs'));
            //not OTP
            //Approval
            //call save function for approval state
        }
        $visitor->bulkSet([
            'escrow_otp'=> rand(100000,999999),
            'last_otp_time'=> \XF::$time,
        ]);
        $visitor->save(); 
        if ($visitor->user_state=='valid' && $visitor->email) {
             $this->sendMail();
        } 
        
        $source_address = $this->getAddress($visitor);
        
        $viewpParams = [
            'data'=> $inputs,
            'source_address' => $source_address,
            'pageSelected' => 'escrow/withdraw',
        ];

        return $this->view('FS\Escrow', 'fs_escrow_otp', $viewpParams);
    
    }
     protected function sendMail()
    {
        $visitor = \XF::visitor();
        $mail = $this->app->mailer()->newMail()->setTo($visitor->email);
        $mail->setTemplate('fs_escrow_send_otp_mail',[
                    'visitor'=>$visitor
                    ]);
        $mail->send();
    }
    protected function isExpiredOtp(){
        $visitor = \XF::visitor();
        $delay = ($this->app()->options()->fs_escrow_otp_expire_time)*60;
        $currentTime = \XF::$time;
        $expiredTime = $visitor->last_otp_time+$delay;
        if ($expiredTime < $currentTime){
            return true;
        }else{
            return false;
        }
    }
    
    protected function saveWithdrawRequest($inputs){
        $visitor = \XF::visitor();
        $withdrawRequest = $this->em()->create('FS\Escrow:WithdrawRequest');
        if ($this->app()->options()->fs_escrow_approval_que_option){
            $request_state = 'visible';
        }else{
            $request_state = 'moderated';
        }

        $newAmount = $visitor->deposit_amount-$inputs['withdraw_amount'];
        $visitor->fastUpdate('deposit_amount',$newAmount);                                
        $escrowService = \xf::app()->service('FS\Escrow:Escrow\EscrowServ');
        $transaction = $escrowService->escrowTransaction($visitor->user_id, $inputs['withdraw_amount'], ($visitor->deposit_amount), 'Withdraw Request', 0);   
            
        $withdrawRequest->bulkSet([
            'user_id'=> $visitor->user_id,
            'amount'=> $inputs['withdraw_amount'],
            'address_from'=> $visitor->crypto_address,
            'address_to'=> $inputs['destination_address'],
            'otp'=> $visitor->escrow_otp,
            'transaction_id'=>$transaction->transaction_id,
            'request_state'=> $request_state,
        ]);
        $req =  $withdrawRequest->save();
        
        if ($req){
            
        
            $this->app()->jobManager()->enqueueUnique('WithDraw', 'FS\Escrow:WithDraw', [], false);
        //    $this->app()->jobManager()->runUnique('WithDraw',20);
        }
        
    }
    
    public function actionWithdrawSave(ParameterBag $params)
    {
        $visitor = \XF::visitor();
        if ($visitor->user_id == 0) {
            throw $this->exception(
                $this->error(\XF::phrase("fs_escrow_not_allowed"))
            );
        }
        $inputs = $this->filterWithdrawAmountInputs();
        if ($visitor->escrow_otp && $visitor->escrow_otp!=$inputs['full_otp'] || $this->isExpiredOtp()){
            throw $this->exception(
                $this->error(\XF::phrase("fs_escrow_otp_does_not_matched_or_expired"))
            );
        }
       
       $this->saveWithdrawRequest($inputs);

        return $this->redirect(
            $this->buildLink('members/'.$visitor->username.'.'.$visitor->user_id.'/#escrow-logs')
        );
        return $this->view('FS\Escrow', 'fs_escrow_otp', $viewpParams);
    
    }

    protected function filterWithdrawAmountInputs()
    {
        $input = $this->filter([
            'destination_address' => 'str',
            'withdraw_amount' => 'int',
            'full_otp'=>'int'
        ]);
        $visitor = \XF::visitor();
        if (isset($input['destination_address']) &&  $input['destination_address']=='') {
            throw $this->exception(
                $this->notFound(\XF::phrase("fs_escrow_address_error"))
            );
        }
        
        
        if ($input['withdraw_amount'] > 0 && $input['withdraw_amount'] < $visitor->deposit_amount) {
            return $input;
        }
        else{
            throw $this->exception(
                $this->notFound(\XF::phrase("fs_escrow_amount_error",['amount'=> $visitor->deposit_amount]))
            );
        }
    }
    public function actionDeposit(ParameterBag $params)
    {
        $visitor = \XF::visitor();
        if ($visitor->user_id == 0) {
            throw $this->exception(
                $this->error(\XF::phrase("fs_escrow_not_allowed"))
            );
        }
        $address = $this->getAddress($visitor);
        if (!file_exists(\XF::getRootDirectory() . '/data/qrcode')) {
            // Create the folder if it doesn't exist
            mkdir(\XF::getRootDirectory() . '/data/qrcode', 0777, true);
        }

        $text = $address;

        $fileName = $visitor->user_id . '.png';
        $path = \XF::getRootDirectory() . '/data/qrcode/' . $fileName;
        
        if (!file_exists($path)){
            $ecc = 'L';
            $pixel_Size = 5;
            $frame_Size = 5;
            \QRcode::png($text, $path, $ecc, $pixel_Size, $frame_Size);
        }


        $viewpParams = [
            'pageSelected' => 'escrow/deposit',
            'address' => $address,
        ];
        return $this->view('FS\Escrow', 'fs_escrow_deposit', $viewpParams);
    }

    protected function getAddress($user){
        
        if ($user->crypto_address && $user->crypto_address !=null){
            return $user->crypto_address;
        }
        
        $ch = curl_init();
        $data = json_encode(array(
            "ExternalId"=>$user->username.'_'.$user->user_id,
            "Currency"=> $this->app()->options()->fs_escrow_currency,
            "New"=>true,
            "ExpectedAmount"=> 0,
            "CallBackLink"=> ($this->app()->options()->fs_escrow_callback_link.'/bithide_callback.php'),
            "publickey"=> $this->app()->options()->fs_escrow_api,
        ));
        curl_setopt($ch, CURLOPT_URL,$this->app()->options()->fs_escrow_bit_base_url."/address/getaddress");
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
        ]);
        curl_setopt($ch, CURLOPT_POSTFIELDS,$data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $server_output = curl_exec($ch);
        $error = curl_error($ch);
        curl_close($ch);
        $response = json_decode($server_output,true);
        if ($response && $response['Status'] == 'Success') { 
            $user->fastUpdate('crypto_address', ($response['Address']));
            return $response['Address'];
        } 
        else{
            if ($error){
                var_dump($error);
            }
        }
        exit;
        
    }

    public function actionDepositSave(ParameterBag $params)
    {
        $this->insertTransaction();

        return $this->redirect(
            // $this->getDynamicRedirect($this->buildLink('escrow/deposit'), false)
            $this->getDynamicRedirect()
        );
    }
   
    protected function insertTransaction()
    {
        $inputs = $this->filterDepositeAmountInputs();
        $visitor = \XF::visitor();
        $newAmount = $inputs['deposit_amount'];
       // $fee = ((intval($this->app()->options()->fs_escrow_fee_percentage)/100)*$inputs['deposit_amount']);
        // if (intval($inputs['fee'])==1){
        //     $newAmount = $inputs['deposit_amount']  - $fee;
        //     //$this->app()->options()->fs_escrow_fee_percentage,
            
        // }
        // else if(intval($inputs['fee'])==0){
        //     $newAmount = $inputs['deposit_amount']  + $fee;
        // }
        
        // if ($inputs['deposit_amount']<$newAmount) {
            
        // throw $this->exception(
        //     $this->notFound(\XF::phrase("please_enter_amount",[
        //         'amount' => $newAmount,
        //     ]))
        // );

        // }
      
        

        //    $visitor->fastUpdate('deposit_amount', ($visitor->deposit_amount + $inputs['deposit_amount']));

        $escrowService = \xf::app()->service('FS\Escrow:Escrow\EscrowServ');
        
        $transaction = $escrowService->escrowTransaction($visitor->user_id, $newAmount, $visitor->deposit_amount, 'Pending', 0);
        
        $depositRequest = $this->em()->create('FS\Escrow:DepositRequest');
        $depositRequest->bulkSet([
            'user_id'=> $visitor->user_id,
            'external_id'=> $visitor->username.'_'.$visitor->user_id,
            'transaction_id'=> $transaction->transaction_id,
            'amount'=> $newAmount,
        ]);
        $depositRequest->save();
        
        // $escrowService->escrowTransaction($visitor->user_id, $inputs['deposit_amount'], $visitor->deposit_amount, 'Deposit', 0);

        return true;
    }

    protected function filterDepositeAmountInputs()
    {
        $input = $this->filter([
            'deposit_amount' => 'int',
            'fee' => 'int',

        ]);

        if ($input['deposit_amount'] > 0) {
            return $input;
        }

        throw $this->exception(
            $this->notFound(\XF::phrase("fs_escrow_amount_required"))
        );
    }

    // public function actionMyEscrow(ParameterBag $params)
    // {
    //     $visitor = \XF::visitor();
    //     if ($visitor->user_id == 0) {
    //         throw $this->exception(
    //             $this->error(\XF::phrase("fs_escrow_not_allowed"))
    //         );
    //     }

    //     $escrows = $this->finder('FS\Escrow:Escrow')->where('user_id', $visitor->user_id);

    //     $viewpParams = [
    //         'escrows' => $escrows->fetch(),
    //     ];
    //     return $this->view('FS\Escrow', 'fs_escrow_escrow_list', $viewpParams);
    // }

    // public function actionMentionedEscrow(ParameterBag $params)
    // {
    //     $visitor = \XF::visitor();
    //     if ($visitor->user_id == 0) {
    //         throw $this->exception(
    //             $this->error(\XF::phrase("fs_escrow_not_allowed"))
    //         );
    //     }

    //     $escrows = $this->finder('FS\Escrow:Escrow')->where('to_user', $visitor->user_id);

    //     $viewpParams = [
    //         'escrows' => $escrows->fetch(),


    //     ];
    //     return $this->view('FS\Escrow', 'fs_escrow_escrow_list', $viewpParams);
    // }

    // public function actionLogs(ParameterBag $params)
    // {
    //     $visitor = \XF::visitor();
    //     if ($visitor->user_id == 0) {
    //         throw $this->exception(
    //             $this->error(\XF::phrase("fs_escrow_not_allowed"))
    //         );
    //     }
    //     $page = $this->filterPage();
    //     $perPage = 2;
    //     $logs = $this->finder('FS\Escrow:Transaction')->where('user_id', $visitor->user_id);
    //     // $logs->limitByPage($page, $perPage);
    //     $viewpParams = [

    //         'logs' => $logs->fetch(),
    //         // 'page'=>$page,
    //         // 'perPage'=>$perPage,
    //         // 'total' => $logs->total(),

    //     ];
    //     return $this->view('FS\Escrow', 'fs_escrow_logs', $viewpParams);
    // }

    public function actionCancel(ParameterBag $params)
    {

        $escrow = $this->assertDataExists($params->escrow_id);

        if ($this->isPost()) {

            $this->cancelEscrow($escrow);

            return $this->redirect(
                $this->getDynamicRedirect($this->buildLink('escrow'), $escrow->Thread)
            );
        } else {

            $viewParams = [
                'escrow' => $escrow,
            ];
            return $this->view('FS\Escrow:Escrow\Cancel', 'fs_escrow_cancel', $viewParams);
        }
    }


    public function actionApprove(ParameterBag $params)
    {
        $escrow = $this->assertDataExists($params->escrow_id);

        if ($this->isPost()) {

            $this->approveEscrow($escrow);

            /** @var Escrow $notifier */
            $notifier = $this->app->notifier('FS\Escrow:Listing\EscrowAlert', $escrow);
            $notifier->escrowApproveAlert();

            return $this->redirect(
                $this->getDynamicRedirect($this->buildLink('escrow'), $escrow->Thread)
            );
        } else {

            $viewParams = [
                'escrow' => $escrow,
            ];
            return $this->view('FS\Escrow:Escrow\Approve', 'fs_escrow_approve', $viewParams);
        }
    }

    public function actionPayments(ParameterBag $params)
    {
        $escrow = $this->assertDataExists($params->escrow_id);

        // /** @var \XF\ControllerPlugin\Delete $plugin */
        // $plugin = $this->plugin('XF:Delete');

        if ($this->isPost()) {

            $this->paymentEscrow($escrow);

            /** @var Escrow $notifier */
            $notifier = $this->app->notifier('FS\Escrow:Listing\EscrowAlert', $escrow);
            $notifier->escrowPaymentAlert();

            return $this->redirect(
                $this->getDynamicRedirect($this->buildLink('escrow'), $escrow->Thread)
            );
        } else {

            $viewParams = [
                'escrow' => $escrow,
            ];
            return $this->view('FS\Escrow:Escrow\Payments', 'fs_escrow_payment', $viewParams);
        }
    }

    protected function cancelEscrow($escrow)
    {
        $visitor = \XF::visitor();

        if ($escrow->user_id != $visitor->user_id && $escrow->to_user != $visitor->user_id) {
            throw $this->exception(
                $this->error(\XF::phrase("fs_escrow_not_allowed"))
            );
        }

        if ($escrow->user_id != $visitor->user_id) {
            $visitor = $this->em()->findOne('XF:User', ['user_id' => $escrow->user_id]);
        }

        if ($escrow) {

            $escrow->Thread->User->fastUpdate('deposit_amount', ($escrow->Thread->User->deposit_amount + $escrow->Transaction->transaction_amount));

            $escrowService = \xf::app()->service('FS\Escrow:Escrow\EscrowServ');

            $escrowService->escrowTransaction($escrow->Thread->User->user_id, $escrow->Transaction->transaction_amount, $escrow->Thread->User->deposit_amount, 'Cancel', $escrow->escrow_id);

            $visitor = \XF::visitor();

            if ($escrow->user_id == $visitor->user_id) {
                $escrow->bulkSet([
                    'escrow_status' => '3',
                    'last_update' => \XF::$time,
                ]);

                /** @var Escrow $notifier */
                $notifier = $this->app->notifier('FS\Escrow:Listing\EscrowAlert', $escrow);
                $notifier->escrowCancelByOwnerAlert();
            } else {
                $escrow->bulkSet([
                    'escrow_status' => '2',
                    'last_update' => \XF::$time,
                ]);
                /** @var Escrow $notifier */
                $notifier = $this->app->notifier('FS\Escrow:Listing\EscrowAlert', $escrow);
                $notifier->escrowCancelAlert();
            }

            $escrow->save();
            // $escrow->fastUpdate('last_update', \XF::$time);
        }
    }

    protected function approveEscrow($escrow)
    {
        $visitor = \XF::visitor();

        if ($escrow->to_user != $visitor->user_id) {
            throw $this->exception(
                $this->error(\XF::phrase("fs_escrow_not_allowed"))
            );
        }

        $escrow->bulkSet([
            'escrow_status' => '1',
            'last_update' => \XF::$time,
        ]);
        $escrow->save();
    }

    protected function paymentEscrow($escrow)
    {
        $visitor = \XF::visitor();

        if ($escrow->user_id != $visitor->user_id) {
            throw $this->exception(
                $this->error(\XF::phrase("fs_escrow_not_allowed"))
            );
        }
        // $user = $this->em()->findOne('XF:User', ['user_id' => $escrow->to_user]);
       $userStatus = $this->transferMoney($escrow,$escrow->escrow_amount,'to_user');
        $escrowService = \xf::app()->service('FS\Escrow:Escrow\EscrowServ');
        if ($userStatus){
            $escrow->User->fastUpdate('deposit_amount', ($escrow->User->deposit_amount + $escrow->escrow_amount));
            $escrowService->escrowTransaction($escrow->User->user_id, $escrow->escrow_amount, $escrow->User->deposit_amount, 'Payment', $escrow->escrow_id);
        }

        $percentageUser = $this->em()->findOne('XF:User', ['user_id' => intval($this->app()->options()->fs_escrow_admin_Id)]);

        if ($percentageUser) {
            $escrowPercentage = $percentageUser->deposit_amount + (($escrow->admin_percentage / 100) * $escrow->escrow_amount);
            $status = $this->transferMoney($escrow,$escrowPercentage,'admin');
            if ($status){
                $percentageUser->fastUpdate('deposit_amount', $escrowPercentage);
                $escrowService->escrowTransaction($percentageUser->user_id, (($escrow->admin_percentage / 100) * $escrow->escrow_amount), $percentageUser->deposit_amount, 'Percentage', $escrow->escrow_id);
                /** @var Escrow $notifier */
                $notifier = $this->app->notifier('FS\Escrow:Listing\EscrowAlert', $escrow);
                $notifier->escrowPercentageHolderUserAlert();
            }
            
        }

        $escrow->bulkSet([
            'escrow_status' => '4',
            'last_update' => \XF::$time,
        ]);
        $escrow->save();
        
    }



    public function transferMoney($escrow,$amount,$type = 'to_user')
    {
        $status = false;
        $response  = $this->requestTransferFunds($escrow,$amount,$type);
        if ($response['Status'] == 'Success') { 
        $escrow->Transaction->fastUpdate('transaction_type','Funds Transferd');
        $status = true;
        }else{
            $errorMessage = implode(' ',preg_split('/(?=[A-Z])/', $response['Error']['Code']));
            $escrow->Transaction->fastUpdate('transaction_type',$errorMessage);
        }
        return $status;
    }


    protected function requestTransferFunds($escrow,$amount,$type){
        $app = \XF::app();
        
        if ($escrow->Thread->User->crypto_address && $escrow->Thread->User->crypto_address !=null){
            $source = $escrow->Thread->User->crypto_address;
        }else{
            $source =  $this->getAddress($escrow->Thread->User);
        }
        if ($type=='to_user'){
            if ($escrow->User->crypto_address && $escrow->User->crypto_address !=null){
                $destination =  $escrow->User->crypto_address;
            }else{
                $destination =  $this->getAddress($escrow->User);
            }
        }
        else if($type=='admin'){
            $percentageUser = $this->em()->findOne('XF:User', ['user_id' => intval($this->app()->options()->fs_escrow_admin_Id)]);
            if ($percentageUser->crypto_address && $percentageUser->crypto_address !=null){
                $destination= $percentageUser->crypto_address;
            }else{
                $destination =  $this->getAddress($percentageUser);
            }
        }

        
        $ch = curl_init();
        $data = json_encode(array(
            "RequestId"=>$escrow->User->user_id.'_'.$escrow->User->username,
            "SourceAddress"=> $source,
            'DestinationAddress'=>$destination, 
            "Currency"=> $app->options()->fs_escrow_currency,
            "Amount"=> $amount,
            "IsSenderCommission"=>true,
            "Comment"=> 'Funds transfer',
            "publickey"=> $app->options()->fs_escrow_api,
        ));
        curl_setopt($ch, CURLOPT_URL,$app->options()->fs_escrow_bit_base_url."/transaction/withdraw");
        curl_setopt($ch, CURLOPT_POST, 1);
    
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
        ]);
        curl_setopt($ch, CURLOPT_POSTFIELDS,$data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $server_output = curl_exec($ch);
        curl_close($ch);
        $response = json_decode($server_output,true);
        return $response;

    } 
    public function updateTransaction($req,$message){
        $transaction = $req->Transaction;
        $user = $req->User;
        $newAmount = $user->deposit_amount+$req->amount;
        $user->fastUpdate('deposit_amount',$newAmount);
        $transaction->bulkSet([
            'transaction_amount'=> $req->amount,
            'transaction_type'=> $message,
            'current_amount'=> $newAmount,
            'created_at'=> (\XF::$time),

        ]);
        $transaction->save();  
    }

    
    /**
     * @param string $id
     * @param array|string|null $with
     * @param null|string $phraseKey
     *
     * @return \FS\Escrow\Entity\Escrow
     */
    protected function assertDataExists($id, array $extraWith = [], $phraseKey = null)
    {
        return $this->assertRecordExists('FS\Escrow:Escrow', $id, $extraWith, $phraseKey);
    }
}