<?php

namespace FS\Escrow\Job;

use XF\Job\AbstractJob;
class WithDraw extends AbstractJob
{

    public function run($maxRunTime)
	{


            $this->transferMoney();
              
              
         return $this->complete();
          
	}
        

	public function getStatusMessage()
	{
		return \XF::phrase('exporting_job...');
	}

	public function canCancel()
	{
		return false;
	}

	public function canTriggerByChoice()
	{
		return false;
	}
    
    

    public  function transferMoney()
    {
        $app = \XF::app();

        $conditions = [
            ['request_state'=>'visible'],
            ['request_state'=>'deleted'],
            
            ];
        $requests = $app->finder('FS\Escrow:WithdrawRequest')->where('is_proceed',0)->whereOr($conditions)->fetch();

        foreach($requests as $req){
            
            if ($req->request_state=='visible'){
                $response  = $this->requestTransferFunds($req);
                if ($response['Status'] == 'Success') { 
                    $req->Transaction->fastUpdate('transaction_type','Funds Transferd');
                } 
                else if ($response['Status'] == 'Error'){ 
                    $errorMessage = implode(' ',preg_split('/(?=[A-Z])/', $response['Error']['Code']));
                    $address = '';
                    if ($response['Error']['Code']=='ValidateAddressFailedError' || $response['Error']['Code']=='AddressNotFoundError'){
                        $address.= $response['Error']['Address'];
                    }else if ($response['Error']['Code']=='InsufficientFundsError'){
                        $address.= $response['Error']['Addresses'][0];
                    };
                    $this->updateTransaction($req,$errorMessage);
                }
            }
            if($req->request_state=='deleted'){
                $this->updateTransaction($req,'Withdraw Rejected');
            }
            $req->fastUpdate('is_proceed',1);

        }
        
        
    }


    public  function requestTransferFunds($req){
        $app = \XF::app();
        $ch = curl_init();
        $data = json_encode(array(
            "RequestId"=>$req->user_id.'_'.$req->User->username,
            "SourceAddress"=> $req->address_from,
            'DestinationAddress'=>$req->address_to, //FS
            "Currency"=> $app->options()->fs_escrow_currency,
            "Amount"=> $req->amount,
            "IsSenderCommission"=>true,
            "Comment"=> 'Funds transfer',
            "publickey"=> $app->options()->fs_escrow_api,
        ));
        curl_setopt($ch, CURLOPT_URL,$app->options()->fs_escrow_bit_base_url."/transaction/withdraw");
        curl_setopt($ch, CURLOPT_POST, 1);
    
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
        ]);
        curl_setopt($ch, CURLOPT_POSTFIELDS,$data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $server_output = curl_exec($ch);
        curl_close($ch);
        $response = json_decode($server_output,true);
        return $response;

    } 
    public function updateTransaction($req,$message){
        $transaction = $req->Transaction;
        $user = $req->User;
        $newAmount = $user->deposit_amount+$req->amount;
        $user->fastUpdate('deposit_amount',$newAmount);
        $transaction->bulkSet([
            'transaction_amount'=> $req->amount,
            'transaction_type'=> $message,
            'current_amount'=> $newAmount,
            'created_at'=> (\XF::$time),

        ]);
        $transaction->save();  
    }
}