<?php

namespace FS\Escrow\XF\Entity;

use XF\Mvc\Entity\Structure;

class User extends XFCP_User
{

    public static function getStructure(Structure $structure)
    {
        $structure = parent::getStructure($structure);

        $structure->columns['deposit_amount'] =  ['type' => self::FLOAT, 'default' => 0];
        $structure->columns['crypto_address'] =  ['type' => self::STR,'default' => NULL];
        $structure->columns['escrow_otp'] =  ['type' => self::INT,'default' => 0];
        $structure->columns['last_otp_time'] =  ['type' => self::INT,'default' => 0];


        

        return $structure;
    }
}