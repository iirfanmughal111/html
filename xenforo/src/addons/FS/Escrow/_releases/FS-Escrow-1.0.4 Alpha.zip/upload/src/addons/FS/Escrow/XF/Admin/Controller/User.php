<?php

namespace FS\Escrow\XF\Admin\Controller;

use XF\Mvc\ParameterBag;

class User extends XFCP_User
{
	protected function userSaveProcess(\XF\Entity\User $user)
	{
        $parent = parent::userSaveProcess($user);
        
        
        $amount = $this->filter(
			
			[
		    'user'=>[
		
				'deposit_amount'=>'uint'
			]
				
			]
		
	);
							
        if ($amount['user']['deposit_amount']<0){
            throw $this->exception(
                $this->error(\XF::phrase("fs_escrow_amount_required"))
            );
        }

		$parent->basicEntitySave($user, $amount['user']);
        $this->insertTransaction($user, $amount['user']['deposit_amount']);
        return $parent;
        
    }

    protected function insertTransaction($user,$amount)
    {

		if(!$amount){
		
			return ;
		}
        $escrowService = \xf::app()->service('FS\Escrow:Escrow\EscrowServ');
        $transaction = $escrowService->escrowTransaction($user->user_id, $amount, $user->deposit_amount, 'Deposit by Admin', 0);
        

        return true;
    }
}