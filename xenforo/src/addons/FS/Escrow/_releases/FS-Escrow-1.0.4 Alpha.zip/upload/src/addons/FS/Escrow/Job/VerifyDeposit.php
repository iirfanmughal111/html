<?php

namespace FS\Escrow\Job;

use XF\Job\AbstractJob;
class VerifyDeposit extends AbstractJob
{

    public function run($maxRunTime)
	{

       
            $this->verifyDeposit();
              
             
         return $this->complete();
            
     
           
	}
        

	public function getStatusMessage()
	{
		return \XF::phrase('deposit...');
	}

	public function canCancel()
	{
		return false;
	}

	public function canTriggerByChoice()
	{
		return false;
	}
    
    public function verifyDeposit()
    {
        $escrowService = \xf::app()->service('FS\Escrow:Escrow\EscrowServ');
        
        $response = $escrowService->getTransactionList();
        
        $app = \XF::app();
        if ($response && $response['Status'] == 'Success') { 
            $app->db()->emptyTable('fs_escrow_bithide_transaction');
            $records = $app->finder('FS\Escrow:TransactionRecord')->where('status',0)->fetch();
            
            foreach ($response['List'] as $key=>$entry){ 
                $temp_fail = json_decode($entry['FailReason']);
                
                $failed = 'null';
                if ($temp_fail!= NULL){
                    $failed = $temp_fail->Code;
                }
                $user_id = explode("_",$entry['ExternalId']);
                $BithideTransactionRecord = $app->em()->create('FS\Escrow:BithideTransactionRecord');
                $BithideTransactionRecord->bulkSet([
                    'Type'=> $entry['Type'],
                    'Date'=> $entry['Date'],
                    'TxId'=> $entry['TxId'] ? $entry['TxId'] : 'NULL',
                    'Cryptocurrency'=> $entry['Cryptocurrency'],
                    'MerchantId'=> $entry['MerchantId'],
                    'MerchantName'=> $entry['MerchantName'],
                    'InitiatorId'=> $entry['InitiatorId'] ? $entry['InitiatorId'] : 'null',
                    'Initiator'=> $entry['Initiator'] ? $entry['Initiator']  :  'null',
                    'Amount'=> $entry['Amount'] ? $entry['Amount'] : 0,
                    'AmountUSD'=> $entry['AmountUSD'] ? $entry['AmountUSD'] : 0,
                    'Rate'=> $entry['Rate'],
                    'Commission'=> $entry['Commission'],
                    'CommissionCurrency'=> $entry['Cryptocurrency'],
                    'SenderAddresses'=> $entry['SenderAddresses'],
                    'DestinationAddress'=> $entry['DestinationAddress'],
                    'ExternalId'=> $entry['ExternalId'] ? $entry['ExternalId'] : 'null',
                    'Comment'=> $entry['Comment'],
                    'Status'=> $entry['Status'],
                    'FailReason'=> $entry['FailReason'] ?  implode(' ',preg_split('/(?=[A-Z])/', $failed)) : 'null',
                    
                ]);
                  $BithideTransactionRecord->save();
                 foreach($records as $rec){ 
                    $user = $app->finder('XF:User')->where('user_id', $rec->user_id)->fetchOne(); 
                    if ($BithideTransactionRecord && $rec->TxId == $BithideTransactionRecord->TxId){
                        $transaction = $app->finder('FS\Escrow:Transaction')->where('user_id', $rec->user_id)->where('transaction_amount', $BithideTransactionRecord->Amount)->where('transaction_type','Pending' )->fetchOne(); 
                         /** @var Escrow $notifier */
                        $notifier = $this->app->notifier('FS\Escrow:Transaction\TransactionAlert', $transaction);

                        if ($transaction && $BithideTransactionRecord->Status == 2){
                            $transaction->bulkSet([
                                'transaction_type'=> 'Deposit',
                                'current_amount'=> ($trans->current_amount+$trans->transaction_amount),
                            ]);
                            $transaction->save();  
                            $rec->fastUpdate('status',1);
                            if ($user){
                                $user->fastUpdate('deposit_amount',($trans->current_amount));                            
                            } 
                        }
                        elseif ($BithideTransactionRecord->Status == 2){                           
                            if ($user){
                                $user->fastUpdate('deposit_amount',($rec->User->deposit_amount+$BithideTransactionRecord->Amount));                            
                            }
                            $escrowService->escrowTransaction($rec->user_id, $BithideTransactionRecord->Amount, ($rec->User->deposit_amount), 'Deposit', 0);
                            $rec->fastUpdate('status',1);
                            $notifier->escrowDepositConfirmAlert(1);
                            

                        }else{
                            $notifier->escrowDepositConfirmAlert(0);
                        }
            
                    }
                
                }

            }
        } 
    }

}