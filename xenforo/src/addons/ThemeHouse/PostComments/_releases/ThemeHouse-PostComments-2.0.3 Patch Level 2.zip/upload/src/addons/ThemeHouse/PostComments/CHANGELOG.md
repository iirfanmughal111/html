CHANGELOG
==========================

## 1.0.3 (`1000370`)

- **Change:** Rebranded add-on to include of OzzyModz
- **Fix:** Minor compatibility issues since the introduction of thread types in XF 2.2+ (#1)

## 1.0.2 Patch Level 2 (`1000292`)

Undocumented changes.